using DataAccess;
using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using Store.API.Extensions;
using StoreApi.Shared.Interfaces;
using System.Text.Json.Serialization;


//using Store.API.Extensions;

var builder = WebApplication.CreateBuilder(args);

var connectionsString = builder.Configuration.GetConnectionString("MyStoreDb");

builder.Services.AddDbContext<StoreDbContext>(options =>
{
    options.UseSqlServer(connectionsString);
});

builder.Services.AddScoped<IProductService<Product>, ProductRepository>();
builder.Services.AddScoped<ICustomerService<Customer>, CustomerRepository>();
builder.Services.AddScoped<IOrderService<Order>, OrderRepository>();



builder.Services.AddControllers().AddJsonOptions(x =>
    x.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.Preserve
);



// Add services to the container.

var app = builder.Build();

app.ProductEndPoints();
app.CustomerEndPoints();
app.OrderEndPoints();



//// Configure the HTTP request pipeline.

//app.UseHttpsRedirection();



app.Run();