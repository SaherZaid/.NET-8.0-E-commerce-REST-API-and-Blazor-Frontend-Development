﻿using DataAccess;
using DataAccess.Entities;
using System.Net.Mail;
using StoreApi.Shared.Interfaces;

namespace Store.API.Extensions;

public static class CustomerEndpointExtensions
{
    public static IEndpointRouteBuilder CustomerEndPoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("api/customer");

        group.MapPost("/", AddCustomer);
        group.MapGet("/email/{email}", GetCustomerByEmail);
        group.MapGet("/", GetAllCustomers);
        group.MapPut("/{id}", UpdateCustomer);
        group.MapDelete("/{id}", DeleteCustomer);

        return app;
    }

    private static async Task<IResult> GetCustomerByEmail(ICustomerService<Customer> repo, string email)
    {
        var customer = await repo.GetCustomerByEmail(email);

        if (customer is null)
        {
            return Results.NotFound($"No customer exists with the given Id: {customer}");
        }
        else
        {
            return Results.Ok(customer);
        }
    }


    private static async Task DeleteCustomer(ICustomerService<Customer> repo, int id)
    {
        await repo.RemoveCustomer(id);
    }

    private static async Task<IResult> UpdateCustomer(ICustomerService<Customer> repo, Customer customer, int id)
    {

        if (id != customer.CustomerId)
        {
            return Results.BadRequest("Customer number mismatch");
        }

        await repo.UpdateCustomer(customer);

        return Results.Ok();
    }

    private static List<Customer> GetAllCustomers(ICustomerService<Customer> repo)
    {
        return repo.GetAllCustomers();
    }

    private static async Task AddCustomer(ICustomerService<Customer> repo, Customer customer)
    {
        await repo.AddCustomer(customer);
    }
}

