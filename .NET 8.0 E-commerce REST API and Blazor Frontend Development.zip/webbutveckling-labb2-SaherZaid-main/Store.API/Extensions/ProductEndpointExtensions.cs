﻿using System.Collections;
using DataAccess;
using DataAccess.Entities;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StoreApi.Shared.Interfaces;

namespace Store.API.Extensions;

public static class ProductEndpointExtensions
{
    public static IEndpointRouteBuilder ProductEndPoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("api/Product");

        group.MapPost("/", AddProduct);
        group.MapGet("/", GetAllProducts);
        group.MapGet("/{id}", GetProductById);
        group.MapGet("/productName/{productName}", GetProductByName);
        group.MapPut("/{id}", UpdateProduct);
        group.MapDelete("/{id}", DeleteProduct);

        return app;
    }

    private static async Task <IResult>GetProductByName(IProductService<Product> repo, string productName)
    {
        var product = await repo.GetProductByName(productName);

        if (product is null)
        {
            return Results.NotFound($"No product exists with the given number: {product}");
        }
        else
        {
            return Results.Ok(product);
        }
    }

   

    private static List<Product> GetAllProducts(IProductService<Product> repo)
    {
        return repo.GetAllProduct();
    }

    private static async Task<IResult> GetProductById(IProductService<Product> repo, int id)
    {
       var product= await repo.GetProductById(id);

        if (product is null)
        {
            return Results.NotFound($"No product exists with the given Id: {id}");
        }
        else
        {
            return Results.Ok(product);
        }
    }

    private static async Task DeleteProduct(IProductService<Product> repo, int id)
    {
        await repo.RemoveProduct(id);
    }

    private static async Task <IResult>UpdateProduct (IProductService<Product> repo, Product product, int id)
    {

        var success = await repo.UpdateProduct(product);
        if (success)
        {
            return Results.Ok(product);

        }

        return Results.BadRequest(product);
    }

    private static async Task AddProduct(IProductService<Product> repo, Product product)
    { 
        await repo.AddProduct(product);
    }
}

