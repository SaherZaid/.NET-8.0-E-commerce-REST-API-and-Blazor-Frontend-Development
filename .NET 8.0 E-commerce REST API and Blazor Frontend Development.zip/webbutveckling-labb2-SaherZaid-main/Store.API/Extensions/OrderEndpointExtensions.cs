﻿using DataAccess;
using DataAccess.Entities;
using StoreApi.Shared.Dtos;
using StoreApi.Shared.Interfaces;
using System.Text.Json.Serialization;
using System.Text.Json;

namespace Store.API.Extensions;

public static class OrderEndpointExtensions
{
    public static IEndpointRouteBuilder OrderEndPoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("api/order");

        group.MapPost("/{customerId}", AddOrder);
        group.MapGet("/", GetAllOrders);

        return app;
    }

    private static async Task<IResult> GetAllOrders(IOrderService<Order> repo)
    {
        var orders = await repo.GetAllOrders();
        var options = new JsonSerializerOptions
        {
            ReferenceHandler = ReferenceHandler.Preserve,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };
        return Results.Json(orders, options, "application/json");
    }

    private static async Task <IResult> AddOrder(IOrderService<Order> repo, int customerId, List<ProductAmountDto> orders)
    {
        await repo.AddOrder(customerId, orders);

        return Results.Ok();
    }
}

