﻿using System.Reflection.Metadata.Ecma335;
using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using StoreApi.Shared.Interfaces;

namespace DataAccess;

public class ProductRepository: IProductService<Product>
{
    private readonly StoreDbContext _context;

    public ProductRepository(StoreDbContext context)
    {
        _context = context;
    }

    public async Task AddProduct(Product product)
    {
        await _context.Products.AddAsync(product);
        await _context.SaveChangesAsync();
    }


    public async Task RemoveProduct(int id)
    {
        var product = _context.Products.FirstOrDefault(p => p.ProductNumber == id);
        _context.Products.Remove(product);
        await _context.SaveChangesAsync();
    }


    public List<Product> GetAllProduct()
    {
        return _context.Products.ToList();

    }


    public async Task<Product?> GetProductById(int id)
    {
        return await _context.Products.FirstOrDefaultAsync(p => p.ProductNumber == id);
    }

    public async Task<Product?> GetProductByName(string name)
    {
        return await _context.Products.FirstOrDefaultAsync(c => c.ProductName == name);
    }

    public async Task<bool> UpdateProduct(Product updatedProduct)
    {
        var existingProduct = await _context.Products.FindAsync(updatedProduct.ProductNumber);
        if (existingProduct is null)
        {
            return false;
        }
        
        _context.Entry(existingProduct).CurrentValues.SetValues(updatedProduct);
        await _context.SaveChangesAsync();
        
        return true;
    }
   
}
