﻿using DataAccess.Entities;
using DataAccess.Migrations;
using Microsoft.EntityFrameworkCore;

namespace DataAccess;

public class StoreDbContext: DbContext
{
    public DbSet<Customer> Customers { get; set; }

    public DbSet<Order> Orders { get; set; }

    public DbSet<Product> Products { get; set; }
    public DbSet<ProductOrder> ProductOrders { get; set; }


    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.ConfigureJunctionTable();
    }

    public StoreDbContext(DbContextOptions options) : base(options)
    {

    }

}