﻿namespace DataAccess.Entities;

public class ProductAmount
{
    public int ProductId { get; set; }
    public int ProductAmounts { get; set; }
}