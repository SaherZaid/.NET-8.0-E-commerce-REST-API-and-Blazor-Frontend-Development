﻿using System.ComponentModel.DataAnnotations;

namespace DataAccess.Entities;

public class Order
{
    public int OrderId { get; set; }
    public int CustomerId { get; set; }
    
    public double TotalPrice { get; set; }
    public Customer customer { get; set; }
    public ICollection<ProductOrder> ProductsInOrder { get; set; } 
}