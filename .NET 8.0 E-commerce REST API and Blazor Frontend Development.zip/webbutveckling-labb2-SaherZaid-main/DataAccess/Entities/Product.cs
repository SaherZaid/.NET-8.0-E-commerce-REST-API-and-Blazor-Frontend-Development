﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DataAccess.Entities
{
    public class Product
    {
        [Key]
        public int ProductNumber { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public double Price { get; set; }
        public int AmountOfProduct { get; set; }  
        public string ProductCategory { get; set; }
        public bool State { get; set; }

       
        public virtual ICollection<ProductOrder> ProductsInOrder { get; set; }

    }
}
