﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Migrations;

public static class DbContextExtensions
{
    public static void ConfigureJunctionTable(this ModelBuilder builder)
    {
        builder.Entity<ProductOrder>()
            .HasKey(eo => new { eo.ProductId, eo.OrderId });

        builder.Entity<ProductOrder>()
            .HasOne(eo => eo.Product)
            .WithMany(e => e.ProductsInOrder)
            .HasForeignKey(eo => eo.ProductId);

        builder.Entity<ProductOrder>()
            .HasOne(eo => eo.Order)
            .WithMany(o => o.ProductsInOrder)
            .HasForeignKey(eo => eo.OrderId);

    }

}