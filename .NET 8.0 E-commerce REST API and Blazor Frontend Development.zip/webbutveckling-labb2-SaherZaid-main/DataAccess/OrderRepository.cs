﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using StoreApi.Shared.Interfaces;
using System.ComponentModel.DataAnnotations;
using StoreApi.Shared.Dtos;

namespace DataAccess;

public class OrderRepository : IOrderService<Order>
{
    private readonly StoreDbContext _context;

    public OrderRepository(StoreDbContext context)
    {
        _context = context;
    }


    public async Task<List<Order>> GetAllOrders()
    {
        var hej = await _context.Orders.Include(o => o.customer).Include(o => o.ProductsInOrder).ToListAsync();
        return await _context.Orders.Include(o => o.customer).Include(o => o.ProductsInOrder).ToListAsync();

    }

    public async Task AddOrder(int customerId, List<ProductAmountDto> orders)
    {

        var newOrder = new Order
        {
            CustomerId = customerId,
            ProductsInOrder = new List<ProductOrder>(),
            TotalPrice = 0 
        };

        
        foreach (var productAmount in orders)
        {
            var product = await _context.Products.FindAsync(productAmount.ProductId);
            if (product != null && product.AmountOfProduct >= productAmount.ProductAmount)
            {
                var productOrder = new ProductOrder
                {
                    ProductId = product.ProductNumber,
                    ProductName = product.ProductName,
                    Amount = productAmount.ProductAmount,
                    UnitPrice = product.Price,
                    Order = newOrder 
                };

                
                product.AmountOfProduct -= productAmount.ProductAmount;

                
                newOrder.ProductsInOrder.Add(productOrder);

                newOrder.TotalPrice += product.Price * productAmount.ProductAmount;
            }
            else
            {
                throw new Exception(
                    $"Product with ID {productAmount.ProductId} is not available in sufficient quantity.");
            }
        }

   
        _context.Orders.Add(newOrder);
        await _context.SaveChangesAsync();
    }

}



