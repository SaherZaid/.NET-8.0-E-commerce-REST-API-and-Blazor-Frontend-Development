﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using StoreApi.Shared.Interfaces;

namespace DataAccess;

public class CustomerRepository: ICustomerService<Customer>
{

    private readonly StoreDbContext _context;

    public CustomerRepository(StoreDbContext context)
    {
        _context = context;
    }
    public async Task AddCustomer(Customer customer)
    {
        await _context.Customers.AddAsync(customer);
        await _context.SaveChangesAsync();
    }

    public List<Customer> GetAllCustomers()
    {
        return _context.Customers.ToList();
    }

    public async Task<Customer?> GetCustomerByEmail(string email)
    {
        return await _context.Customers.FirstOrDefaultAsync(c => c.Email == email);
    }

    public async Task UpdateCustomer(Customer customer)
    {
        var existingCustomer = await _context.Customers.FindAsync(customer.CustomerId);
        if (existingCustomer != null)
        {
            _context.Entry(existingCustomer).CurrentValues.SetValues(customer);
            await _context.SaveChangesAsync();
        }
    }

    public async Task RemoveCustomer(int id)
    {
        var customer = _context.Customers.FirstOrDefault(c => c.CustomerId == id);
        _context.Customers.Remove(customer);
        await _context.SaveChangesAsync();
    }
}

