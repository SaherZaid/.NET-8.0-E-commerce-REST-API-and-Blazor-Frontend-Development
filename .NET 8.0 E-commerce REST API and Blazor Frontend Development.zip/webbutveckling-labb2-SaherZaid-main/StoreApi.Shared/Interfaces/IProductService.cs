﻿namespace StoreApi.Shared.Interfaces;

public interface IProductService <T> where T : class
{
    Task AddProduct(T product);
    Task RemoveProduct(int id);
    List<T> GetAllProduct();
    Task<T?> GetProductById(int id);
    Task<T?> GetProductByName(string productName);
    Task<bool> UpdateProduct(T product);

}