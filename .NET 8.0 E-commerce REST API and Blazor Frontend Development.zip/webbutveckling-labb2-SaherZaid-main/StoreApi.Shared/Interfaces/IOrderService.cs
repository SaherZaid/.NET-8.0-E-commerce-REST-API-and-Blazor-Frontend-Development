﻿using StoreApi.Shared.Dtos;

namespace StoreApi.Shared.Interfaces;

public interface IOrderService<T> where T : class
{
    Task<List<T>> GetAllOrders();

    Task AddOrder(int customerId, List<ProductAmountDto> orders);

}