﻿namespace StoreApi.Shared.Interfaces;

public interface ICustomerService<T> where T : class
{
    Task AddCustomer(T customer); 
    List<T> GetAllCustomers();
    Task<T?> GetCustomerByEmail(string email);
    Task UpdateCustomer(T customer);
    Task RemoveCustomer(int id);
}