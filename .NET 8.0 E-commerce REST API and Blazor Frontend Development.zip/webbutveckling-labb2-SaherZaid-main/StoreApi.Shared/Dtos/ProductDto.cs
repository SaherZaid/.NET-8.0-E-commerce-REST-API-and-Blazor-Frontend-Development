﻿using System.ComponentModel.DataAnnotations;

namespace StoreApi.Shared.Dtos;

public class ProductDto
{
    public int ProductNumber { get; set; }

    [Required]
    public string ProductName { get; set; }

    public string ProductDescription { get; set; }
    [Required]
    public double Price { get; set; }
    public int AmountOfProduct { get; set; }
    public string ProductCategory { get; set; } 
    public bool State { get; set; }
}