﻿namespace StoreApi.Shared.Dtos;

public class ProductOrderDto
{
    public int Id { get; set; }

    public int ProductId { get; set; }

    public ProductDto Product { get; set; }

    public int OrderId { get; set; }

    public OrderDto Order { get; set; }
    public double UnitPrice { get; set; }
    public int Amount { get; set; }
}