﻿using System.ComponentModel.DataAnnotations;

namespace StoreApi.Shared.Dtos;

public class OrderDto
{
    public int OrderId { get; set; }
    public int CustomerId { get; set; }
    public double TotalPrice { get; set; }
    public CustomerDto customer { get; set; }
    public ICollection<ProductDto> Products { get; set; } 
    public ICollection<ProductOrderDto> ProductOrderDtos { get; set; }
}