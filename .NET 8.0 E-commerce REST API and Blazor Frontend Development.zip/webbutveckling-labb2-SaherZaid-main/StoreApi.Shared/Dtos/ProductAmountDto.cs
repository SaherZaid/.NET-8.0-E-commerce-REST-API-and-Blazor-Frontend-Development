﻿namespace StoreApi.Shared.Dtos;

public class ProductAmountDto
{
    public int ProductId { get; set; }
    public int ProductAmount { get; set; }
}