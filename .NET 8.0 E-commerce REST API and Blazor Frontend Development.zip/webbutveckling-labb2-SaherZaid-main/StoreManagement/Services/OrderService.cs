﻿using DataAccess.Entities;
using System.ComponentModel.DataAnnotations;
using StoreApi.Shared.Dtos;
using StoreApi.Shared.Dtos;
using StoreApi.Shared.Interfaces;
using System.Text.Json.Serialization;
using System.Text.Json;

namespace StoreManagement.Services;

public class OrderService : IOrderService<Order>
{
    private readonly HttpClient _httpClient;

    public OrderService(IHttpClientFactory factory)
    {
        _httpClient = factory.CreateClient("StoreApi");
    }

    public async Task<List<Order>> GetAllOrders()
    {
        var response = await _httpClient.GetAsync("api/order");

        if (!response.IsSuccessStatusCode)
        {
            return new List<Order>();
        }

        var options = new JsonSerializerOptions
        {
            ReferenceHandler = ReferenceHandler.Preserve,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        var result = await response.Content.ReadFromJsonAsync<List<Order>>(options);
        return result ?? new List<Order>();
    }

    public async Task AddOrder(int customerId, List<ProductAmountDto> orders)
    {

        var response = await _httpClient.PostAsJsonAsync($"/api/Order/{customerId}", orders);

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Failed to add order. Status code: {response.StatusCode}");
        }


    }

    
}
