﻿using StoreApi.Shared.Interfaces;
using System.Net.Http;
using DataAccess.Entities;

namespace StoreManagement.Services;

public class ProductService : IProductService<Product>
{
    private readonly HttpClient _httpClient;

    public ProductService(IHttpClientFactory factory)
    {
        _httpClient = factory.CreateClient("StoreApi");
    }

    public async Task AddProduct(Product product)
    {
        var response = await _httpClient.PostAsJsonAsync("api/Product", product);

        if (!response.IsSuccessStatusCode)
        {
            return;
        }
    }

    public async Task RemoveProduct(int id)
    {
        var response = await _httpClient.DeleteAsync($"api/Product/{id}");

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception("Failed to delete the product");

           
        }

    }

    public List<Product> GetAllProduct()
    {
        var response = _httpClient.GetAsync("api/Product").Result;

        if (!response.IsSuccessStatusCode)
        {
            return new List<Product>();
        }

        var result = response.Content.ReadFromJsonAsync<List<Product>>().Result;
        return result ?? new List<Product>();
    }

    public async Task<Product?> GetProductById(int id)
    {
        var response = await _httpClient.GetAsync($"api/Product/{id}");

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var result = await response.Content.ReadFromJsonAsync<Product>();
        return result;
    }

    public async Task<Product?> GetProductByName(string productName)
    {
        var response = await _httpClient.GetAsync($"api/Product/productName/{productName}");

        if (response.IsSuccessStatusCode)
        {
            var result = await response.Content.ReadFromJsonAsync<Product>();
            return result;
        }

        return null;
    }

    public async Task<bool> UpdateProduct(Product product)
    {

        var response = await _httpClient.PutAsJsonAsync($"api/Product/{product.ProductNumber}", product);

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Failed to update product. Status code: {response.StatusCode}");
        }

        return response.IsSuccessStatusCode;

    }

}

