﻿using DataAccess.Entities;
//using StoreApi.Shared.Dtos;
using StoreApi.Shared.Interfaces;

namespace StoreManagement.Services;

    public class CustomerService : ICustomerService<Customer>
    {
        private readonly HttpClient _httpClient;

        public CustomerService(IHttpClientFactory factory)
        {
            _httpClient = factory.CreateClient("StoreApi");
        }

        public List<Customer> GetAllCustomers()
        {
            var response = _httpClient.GetAsync("api/Customer").Result;

            if (!response.IsSuccessStatusCode)
            {
                return new List<Customer>();
            }

            var result = response.Content.ReadFromJsonAsync<List<Customer>>().Result;
            return result ?? new List<Customer>();
        }

        

        public async Task AddCustomer(Customer newCustomer)
        {
            var response = await _httpClient.PostAsJsonAsync("api/customer/", newCustomer);

            if (!response.IsSuccessStatusCode)
            {
                return;
            }
        }
        
        public async Task UpdateCustomer(Customer updatedCustomer)
        {
            var response = await _httpClient.PutAsJsonAsync($"/api/customer/{updatedCustomer.CustomerId}", updatedCustomer);

            if (!response.IsSuccessStatusCode) 
            {
                  throw new Exception($"Failed to update customer. Status code: {response.StatusCode}");
            }
        }

        public async Task<Customer?> GetCustomerByEmail(string email)
        {
            var response = await _httpClient.GetAsync($"api/Customer/email/{email}");

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<Customer>(); 
                return result;
            }

            return null; 
        }
        
        public async Task RemoveCustomer(int id)
        {
            var response = await _httpClient.DeleteAsync($"/api/customer/{id}");

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to delete customer. Status code: {response.StatusCode}");
            }
        }


    }
