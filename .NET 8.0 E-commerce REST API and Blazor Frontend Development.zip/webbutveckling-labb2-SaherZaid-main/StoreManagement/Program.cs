using DataAccess.Entities;
using MudBlazor.Services;
//using StoreApi.Shared.Dtos;
using StoreApi.Shared.Interfaces;
using StoreManagement.Components;
using StoreManagement.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddMudServices();

builder.Services.AddHttpClient("StoreApi",
    client => 
        client.BaseAddress = new Uri("http://localhost:5250")
    );

builder.Services.AddScoped<IProductService<Product>, ProductService>();

builder.Services.AddScoped<ICustomerService<Customer>, CustomerService>();

builder.Services.AddScoped<IOrderService<Order>, OrderService>();




var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
